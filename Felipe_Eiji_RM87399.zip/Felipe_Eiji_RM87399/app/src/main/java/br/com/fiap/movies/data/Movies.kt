package br.com.fiap.movies.data

import java.math.BigDecimal

class Movies(
    val nome: String,
    val sinopse: String,
    val classificação: Int,
    val genero: String,
    val duracao: BigDecimal

) {


}
